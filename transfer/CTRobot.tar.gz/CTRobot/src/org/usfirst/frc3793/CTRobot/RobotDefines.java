package org.usfirst.frc3793.CTRobot;

public class RobotDefines {
	public static boolean simulation = true;
	public static boolean debug = true;
	public static double  cEncPulseDist = 0.0349;
	public static double  cEncPulseDistSim = 0.042; //TODO: Needs to be changed
}
